export interface StormeeConfig {
    conciergeId: string;
    organizationId: string;
    organizationName: string;
    username: string;
    useremailId: string;
    rlefVoiceTaskId: string;
    assistant_type?: string;
    userId: string;
    voiceAgentMongoId: string;
    environmentUrl?: string;
}
export declare function useStormeeAudio(config: StormeeConfig): {
    startRecording: () => void;
    stopRecording: () => void;
    transcription: string;
};
//# sourceMappingURL=UseRattStormee.d.ts.map