import { type TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    multiply(a: number, b: number): number;
    startRecording(): Promise<boolean>;
    stopRecording(): Promise<boolean>;
    addListener(eventName: string): void;
    removeListeners(count: number): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeStormeeAudio.d.ts.map