export declare class RattCaptureService {
    private serverUrl;
    private rattAgentDetails;
    onTranscription: (text: string) => void;
    onStateChange: (state: any) => void;
    private client;
    private micSubscription;
    constructor(serverUrl: string, rattAgentDetails: any, onTranscription: (text: string) => void, onStateChange: (state: any) => void);
    init(): Promise<void>;
    startSession(): Promise<void>;
    stopSession(): Promise<void>;
    private startNativeMic;
    private stopNativeMic;
}
//# sourceMappingURL=RattCaptureService.d.ts.map